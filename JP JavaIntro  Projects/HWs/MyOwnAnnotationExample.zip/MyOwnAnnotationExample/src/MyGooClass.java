import java.lang.annotation.*;


public class MyGooClass {
    
    public MyGooClass() {
       
    }
    
    @RequestForEnhancement(
    id   =2323,
    synopsis="let to fly",
    engineer="Raul Ramirez",
    date    = "28/11/07"    
    )
    public void flyUnderPressure(){
        
    }
    
}
