package myownautoshopproject;

public interface EngineInterface {
    public void test(int speed);
}
