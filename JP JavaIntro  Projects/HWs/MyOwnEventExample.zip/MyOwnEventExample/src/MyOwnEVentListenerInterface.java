
public interface MyOwnEVentListenerInterface{
    
    
    public void algoPaso(MyOwnEvent event);
    
}
