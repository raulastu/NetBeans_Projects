

package myrunnableproject;


public class MyMain {
    
    
    public MyMain() {
    }
    
    public static void main(String[] args) {
        new MyCurrentDate("rChi");
        new MyCurrentDate("wii");
        new MyCurrentDate(">.<");
    }
    
}
