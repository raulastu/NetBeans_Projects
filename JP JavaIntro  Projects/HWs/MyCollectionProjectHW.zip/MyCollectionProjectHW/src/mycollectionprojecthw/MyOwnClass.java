

package mycollectionprojecthw;

public class MyOwnClass {
    String name;
    int age;
    public MyOwnClass(String name,int age) {
        this.name=name;
        this.age=age;
    }
    
}
