/*
 * TestComputeClassWizard.java
 *
 * Created on 19 de diciembre de 2007, 11:55 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author Administrado
 */
public class TestComputeClassWizard {
    
    /** Creates a new instance of TestComputeClassWizard */
    public TestComputeClassWizard() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
